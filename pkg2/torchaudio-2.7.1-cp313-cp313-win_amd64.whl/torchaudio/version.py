__version__ = '2.7.1+cpu'
git_version = '95c61b4168fc5133be8dd8c1337d929d066ae6cf'
